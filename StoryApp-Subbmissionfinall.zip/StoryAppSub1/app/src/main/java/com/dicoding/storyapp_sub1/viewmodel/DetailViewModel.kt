package com.dicoding.storyapp_sub1.viewmodel

import androidx.lifecycle.ViewModel
import com.dicoding.storyapp_sub1.data.response.ListStoryItem

class DetailViewModel: ViewModel() {
    lateinit var storyItem: ListStoryItem

    fun setDetailStory(story: ListStoryItem) : ListStoryItem{
        storyItem = story
        return storyItem
    }
}