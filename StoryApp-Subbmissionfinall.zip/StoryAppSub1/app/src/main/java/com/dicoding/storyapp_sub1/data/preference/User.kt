package com.dicoding.storyapp_sub1.data.preference

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class User(
    val token: String,
    val name: String,
    val userId: String,
    val isLoggedIn: Boolean = false
): Parcelable

