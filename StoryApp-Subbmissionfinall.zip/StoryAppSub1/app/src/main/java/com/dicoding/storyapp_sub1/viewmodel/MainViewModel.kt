package com.dicoding.storyapp_sub1.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asFlow
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.dicoding.storyapp_sub1.data.preference.User
import com.dicoding.storyapp_sub1.data.response.ListStoryItem
import com.dicoding.storyapp_sub1.data.response.UserRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

class MainViewModel(private val repository: UserRepository) : ViewModel() {

    val getStory: LiveData<PagingData<ListStoryItem>> =
        repository.getStory().cachedIn(viewModelScope)

    fun getStories(): LiveData<PagingData<ListStoryItem>> {
        return repository.getStory().cachedIn(viewModelScope)
        }

    fun getSession(): LiveData<User> {
        viewModelScope.launch {
            repository.getSession().collect {
                sessions.value = it
            }
        }
        return sessions
    }

    val sessions = MutableLiveData<User>()



    suspend fun logout() {
        repository.logout()
    }
}
