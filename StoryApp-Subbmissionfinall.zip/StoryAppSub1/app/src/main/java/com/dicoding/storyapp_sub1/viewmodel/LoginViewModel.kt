package com.dicoding.storyapp_sub1.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.dicoding.storyapp_sub1.data.preference.User
import com.dicoding.storyapp_sub1.data.response.LoginResponse
import com.dicoding.storyapp_sub1.data.response.UserRepository

class LoginViewModel(private val repository: UserRepository) : ViewModel() {
    var loginResult : MutableLiveData<LoginResponse> = repository.loginResult
    var isLoading: LiveData<Boolean> = repository.isLoading


    fun login(email: String, password: String) {
        return repository.login(email, password)
    }

    suspend fun saveSession(user: User) {
        repository.saveSession(user)
    }
}

