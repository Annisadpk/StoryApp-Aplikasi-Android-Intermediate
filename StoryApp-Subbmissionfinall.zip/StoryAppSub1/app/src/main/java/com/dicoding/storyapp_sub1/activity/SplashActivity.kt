package com.dicoding.storyapp_sub1.activity

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.dicoding.storyapp_sub1.R
import com.dicoding.storyapp_sub1.data.preference.UserPreference
import com.dicoding.storyapp_sub1.data.preference.myDataStore
import kotlinx.coroutines.flow.first

import kotlinx.coroutines.runBlocking

class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        // Menggunakan runBlocking untuk memanggil first() di dalam korutin
        runBlocking {
            val userPreference = UserPreference.getInstance(myDataStore)
            val isLoggedIn = userPreference.getUserSession().first().isLoggedIn

            // Redirect ke LoginActivity jika belum login atau ke MainActivity jika sudah login
            Handler(Looper.getMainLooper()).postDelayed({
                val intent = if (isLoggedIn) {
                    Intent(this@SplashActivity, MainActivity::class.java)
                } else {
                    Intent(this@SplashActivity, LoginActivity::class.java)
                }
                startActivity(intent)
                finish()
            }, SPLASH_DELAY)
        }
    }

    private companion object {
        const val SPLASH_DELAY = 1000L
    }
}


