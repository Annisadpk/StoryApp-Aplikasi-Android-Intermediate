package com.dicoding.storyapp_sub1.viewmodel
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.dicoding.storyapp_sub1.data.response.Result
import com.dicoding.storyapp_sub1.data.response.StoryResponse
import com.dicoding.storyapp_sub1.data.response.UserRepository


class MapsViewModel(
    private val repository: UserRepository
) : ViewModel() {

    suspend fun getStoriesWithLocation(): LiveData<Result<StoryResponse>> {
        return repository.getStoriesWithLocation()
    }


}
