package com.dicoding.storyapp_sub1.activity


import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.paging.PagingData
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.storyapp_sub1.adapter.StoryAdapter
import com.dicoding.storyapp_sub1.databinding.ActivityMainBinding
import com.dicoding.storyapp_sub1.viewmodel.MainViewModel
import com.dicoding.storyapp_sub1.viewmodel.ViewModelFactory
import kotlinx.coroutines.launch


class MainActivity : AppCompatActivity() {
    private val viewModel by viewModels<MainViewModel> {
        ViewModelFactory.getInstance(this)
    }

    private var _binding: ActivityMainBinding? = null
    private val binding get() = _binding!!

    // Declare the StoryAdapter as a class-level property
    private val adapter = StoryAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        _binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.logoutButton.setOnClickListener {
            lifecycleScope.launch {
                viewModel.logout()
            }
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
        binding.addStory.setOnClickListener {
            val intent = Intent(this, AddstoryActivity::class.java)
            startActivity(intent)
        }
        binding.maps.setOnClickListener {
            val intent = Intent(this, MapsActivity::class.java)
            startActivity(intent)
        }

        // Set the adapter to the RecyclerView
        binding.rvStory.adapter = adapter

        getSession()
    }

    override fun onResume() {
        super.onResume()
        viewModel.sessions.value?.let {
            viewModel.getStories().observe(this@MainActivity) { pagingData ->
                adapter.submitData(lifecycle, pagingData)
            }
        }
        adapter.submitData(lifecycle, PagingData.empty())
    }

    private fun getSession() {
        viewModel.getSession().observe(this) { user ->
            if (!user.isLoggedIn) {
            } else {
                lifecycleScope.launch {
                    viewModel.getStory.observe(this@MainActivity) { result ->
                        adapter.submitData(lifecycle, result)
                        showLoading(false)

                    }
                }
            }
        }
        showStory()
    }

    private fun showStory() {
        val layoutManager = LinearLayoutManager(this)
        binding.rvStory.layoutManager = layoutManager
    }

    private fun showLoading(state: Boolean) {
        if (state) binding.progressBar.visibility = View.VISIBLE
        else binding.progressBar.visibility = View.GONE
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    companion object {
        const val EXTRA_USER = "user"
    }

}

