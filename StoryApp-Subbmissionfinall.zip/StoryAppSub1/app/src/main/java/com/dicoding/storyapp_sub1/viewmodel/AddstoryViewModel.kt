package com.dicoding.storyapp_sub1.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.dicoding.storyapp_sub1.data.response.AddstoryResponse
import com.dicoding.storyapp_sub1.data.response.UserRepository
import okhttp3.MultipartBody
import okhttp3.RequestBody
import com.dicoding.storyapp_sub1.data.response.Result

class AddstoryViewModel (
    private val repository: UserRepository
    ) : ViewModel() {

    suspend fun uploadStory(
        file: MultipartBody.Part,
        description: RequestBody,
        lat: Float,
        long: Float
    ): LiveData<Result<AddstoryResponse>> {
        return repository.uploadImage(file, description, lat, long)
    }
}