package com.dicoding.storyapp_sub1.activity

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.dicoding.storyapp_sub1.R
import com.dicoding.storyapp_sub1.data.preference.User
import com.dicoding.storyapp_sub1.databinding.ActivityLoginBinding
import com.dicoding.storyapp_sub1.viewmodel.LoginViewModel
import com.dicoding.storyapp_sub1.viewmodel.ViewModelFactory
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {
    private val viewModel by viewModels<LoginViewModel> {
        ViewModelFactory.getInstance(this)
    }

    private var _binding: ActivityLoginBinding? = null
    private val binding get() = _binding!!

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        _binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        showLoading(false)
        setupView()
        setupAction()
        playAnimation()

        val toRegistTextView = findViewById<TextView>(R.id.to_regist)
        toRegistTextView.setOnClickListener {
            val intent = Intent(this@LoginActivity, RegisterActivity::class.java)
            startActivity(intent)
        }

    }

    private fun setupView() {
        @Suppress("DEPRECATION")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.hide(WindowInsets.Type.statusBars())
        } else {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
            )
        }
        supportActionBar?.hide()
    }

    private fun setupAction() {
        binding.myButton.setOnClickListener {
            val email = binding.emailEditText.text.toString()
            val password = binding.passwordEditText.text.toString()

            if (email.isEmpty()) {
                binding.emailEditText.error = getString(R.string.emailkosong)
            } else if (password.isEmpty()) {
                binding.passwordEditText.error = getString(R.string.paswordkosong)
            } else {
                showLoading(true) // Show the loading progress bar

                viewModel.login(email, password)
                viewModel.loginResult.observe(this) { result ->
                    showLoading(false) // Hide the loading progress bar when the result is received

                    if (!result.error) {
                        // Successful login, save the session
                        save(
                            User(
                                result.loginResult!!.token.toString(),
                                result.loginResult!!.name.toString(),
                                result.loginResult!!.userId.toString(),
                                true
                            )
                        )
                    } else {
                        // Login error, show error message
                        showToast(result.message)
                    }
                }
            }
        }
    }

    private fun save(session: User) {
        lifecycleScope.launch {
            viewModel.saveSession(session)
            val intent = Intent(this@LoginActivity, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
            ViewModelFactory.clearInstance()
            startActivity(intent)
        }
    }



    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

    private fun showToast(message: String?) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progresslogin.visibility = if (isLoading) View.VISIBLE else View.GONE
        binding.myButton.isEnabled = !isLoading
    }

    private fun playAnimation() {
        ObjectAnimator.ofFloat(binding.imagewelcome, View.TRANSLATION_X, -30f, 30f).apply {
            duration = 6000
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
        }.start()

        val animatorSet = AnimatorSet()
        animatorSet.playSequentially(
            ObjectAnimator.ofFloat(binding.lets, View.ALPHA, 0f, 1f).setDuration(150),
            ObjectAnimator.ofFloat(binding.welcome, View.ALPHA, 0f, 1f).setDuration(150),
            ObjectAnimator.ofFloat(binding.emailTextView, View.ALPHA, 0f, 1f).setDuration(150),
            ObjectAnimator.ofFloat(binding.emailEditTextLayout, View.ALPHA, 0f, 1f).setDuration(150),
            ObjectAnimator.ofFloat(binding.emailEditText, View.ALPHA, 0f, 1f).setDuration(150),
            ObjectAnimator.ofFloat(binding.pwdTextView, View.ALPHA, 0f, 1f).setDuration(150),
            ObjectAnimator.ofFloat(binding.passwordEditTextLayout, View.ALPHA, 0f, 1f).setDuration(150),
            ObjectAnimator.ofFloat(binding.passwordEditText, View.ALPHA, 0f, 1f).setDuration(150),
            ObjectAnimator.ofFloat(binding.myButton, View.ALPHA, 0f, 1f).setDuration(150),
            ObjectAnimator.ofFloat(binding.ln1, View.ALPHA, 0f, 1f).setDuration(150)
        )

        animatorSet.start()
    }

}
