// RegisterActivity.kt
package com.dicoding.storyapp_sub1.activity

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.View.VISIBLE
import android.view.View.GONE
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.dicoding.storyapp_sub1.data.response.RegisterResponse
import com.dicoding.storyapp_sub1.databinding.ActivityRegisterBinding
import com.dicoding.storyapp_sub1.viewmodel.RegisterViewModel
import com.dicoding.storyapp_sub1.viewmodel.ViewModelFactory
import com.google.gson.Gson
import kotlinx.coroutines.launch
import retrofit2.HttpException
import com.dicoding.storyapp_sub1.R

class RegisterActivity : AppCompatActivity() {
    private val viewModel by viewModels<RegisterViewModel> {
        ViewModelFactory.getInstance(this)
    }
    private var _binding: ActivityRegisterBinding? = null
    private val binding get() = _binding!!

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        _binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)
        showLoading(false)

        setupView()
        setupAction()

        playAnimation()

        val toLoginTextView = binding.toLogin
        toLoginTextView.setOnClickListener {
            val intent = Intent(this@RegisterActivity, LoginActivity::class.java)
            startActivity(intent)
        }
    }
    private fun playAnimation() {
        ObjectAnimator.ofFloat(binding.signuptext, View.TRANSLATION_X, -30f, 30f).apply {
            duration = 6000
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
        }.start()

        val animatorSet = AnimatorSet()
        animatorSet.playSequentially(
            ObjectAnimator.ofFloat(binding.nameTextView, View.ALPHA, 0f, 1f).setDuration(150),
            ObjectAnimator.ofFloat(binding.nameEditTextLayout, View.ALPHA, 0f, 1f)
                .setDuration(150),
            ObjectAnimator.ofFloat(binding.nameEditText, View.ALPHA, 0f, 1f).setDuration(150),
            ObjectAnimator.ofFloat(binding.emailTextView, View.ALPHA, 0f, 1f).setDuration(150),
            ObjectAnimator.ofFloat(binding.emailTextView, View.ALPHA, 0f, 1f).setDuration(150),
            ObjectAnimator.ofFloat(binding.emailEditTextLayout, View.ALPHA, 0f, 1f)
                .setDuration(150),
            ObjectAnimator.ofFloat(binding.emailEditText, View.ALPHA, 0f, 1f).setDuration(150),
            ObjectAnimator.ofFloat(binding.pwdTextView, View.ALPHA, 0f, 1f).setDuration(150),
            ObjectAnimator.ofFloat(binding.passwordEditTextLayout, View.ALPHA, 0f, 1f)
                .setDuration(150),
            ObjectAnimator.ofFloat(binding.passwordEditText, View.ALPHA, 0f, 1f)
                .setDuration(150),
            ObjectAnimator.ofFloat(binding.signupButton, View.ALPHA, 0f, 1f).setDuration(150),
            ObjectAnimator.ofFloat(binding.ln, View.ALPHA, 0f, 1f).setDuration(150)
        )

        animatorSet.start()
    }

        private fun setupView() {
            @Suppress("DEPRECATION")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                window.insetsController?.hide(WindowInsets.Type.statusBars())
            } else {
                window.setFlags(
                    WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    WindowManager.LayoutParams.FLAG_FULLSCREEN
                )
            }
            supportActionBar?.hide()
        }

        private fun setupAction() {
            binding.signupButton.setOnClickListener {
                showLoading(true)
                val name = binding.nameEditText.text.toString()
                val email = binding.emailEditText.text.toString()
                val password = binding.passwordEditText.text.toString()

                if (name.isEmpty()) {
                    showLoading(false)
                    binding.nameEditTextLayout.error = getString(R.string.usernamekosong)
                } else if (email.isEmpty()) {
                    showLoading(false)
                    binding.emailEditTextLayout.error = getString(R.string.emailkosong)
                } else if (password.isEmpty()) {
                    showLoading(false)
                    binding.passwordEditTextLayout.error = getString(R.string.paswordkosong)
                }

                lifecycleScope.launch {
                    try {
                        val response = viewModel.register(name, email, password)
                        showLoading(false)
                        showToast(response.message)
                        AlertDialog.Builder(this@RegisterActivity).apply {
                            setTitle("Succes!")
                            setMessage(getString(R.string.sukses))
                            setPositiveButton(getString(R.string.ok)) { _, _ ->
                                val intent = Intent(context, LoginActivity::class.java)
                                intent.flags =
                                    Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
                                startActivity(intent)
                                finish()
                            }
                            create()
                            show()
                        }
                    } catch (e: HttpException) {
                        showLoading(false)
                        val errorBody = e.response()?.errorBody()?.string()
                        val errorResponse = Gson().fromJson(errorBody, RegisterResponse::class.java)
                        showToast(errorResponse.message)
                    }
                }


            }
        }

        private fun showToast(message: String) {
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
        }

        private fun showLoading(isLoading: Boolean) {
            binding.progressBar.visibility =
                if (isLoading) VISIBLE else GONE
            binding.signupButton.isEnabled = !isLoading
        }


    }

