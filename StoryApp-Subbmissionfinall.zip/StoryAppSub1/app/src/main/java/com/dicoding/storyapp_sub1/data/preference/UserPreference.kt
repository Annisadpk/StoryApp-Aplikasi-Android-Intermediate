package com.dicoding.storyapp_sub1.data.preference

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.myDataStore: DataStore<Preferences> by preferencesDataStore(name = "my_session")
class UserPreference private constructor(private val dataStore: DataStore<Preferences>) {

    companion object {
        @Volatile
        private var INSTANCE: UserPreference? = null
        private val ID_User = stringPreferencesKey("userId")
        private val KEY_Token = stringPreferencesKey("token")
        private val KEY_Name = stringPreferencesKey("name")
        private val KEY_Login = booleanPreferencesKey("isLoggedIn")

        fun getInstance(dataStore: DataStore<Preferences>): UserPreference {
            return INSTANCE ?: synchronized(this) {
                val _instance = UserPreference(dataStore)
                INSTANCE = _instance
                _instance
            }
        }
    }

    suspend fun saveUserSession(user: User) {
        dataStore.edit { preferences ->
            preferences[KEY_Token] = user.token
            preferences[KEY_Name] = user.name
            preferences[ID_User] = user.userId
            preferences[KEY_Login] = true
        }
    }


    fun getUserSession(): Flow<User> {
        return dataStore.data.map { preferences ->
            User(
                preferences[KEY_Token] ?: "",
                preferences[KEY_Name] ?: "",
                preferences[ID_User] ?: "",
                preferences[KEY_Login] ?: false
            )
        }
    }


    suspend fun deleteUserSession() {
        dataStore.edit { preferences ->
            preferences[KEY_Token] = ""
            preferences[KEY_Name] = ""
            preferences[ID_User] = ""
            preferences[KEY_Login] = false
        }
    }
}
