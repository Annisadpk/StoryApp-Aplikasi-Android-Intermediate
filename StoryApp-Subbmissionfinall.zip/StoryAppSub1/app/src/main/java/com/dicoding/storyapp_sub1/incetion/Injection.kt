package com.dicoding.storyapp_sub1.incetion

import android.content.Context
import com.dicoding.storyapp_sub1.data.preference.UserPreference
import com.dicoding.storyapp_sub1.data.preference.myDataStore
import com.dicoding.storyapp_sub1.data.response.UserRepository
import com.dicoding.storyapp_sub1.database.DatabaseStory
import com.dicoding.storyapp_sub1.retrofit.ApiConfig
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

object Injection {
    fun injectionRepository(context: Context): UserRepository = runBlocking {
        val pref = UserPreference.getInstance(context.myDataStore)
        val user = pref.getUserSession().first()
        val apiService = ApiConfig.getApiService(user.token)
        val database = DatabaseStory.getDatabase(context)
        UserRepository.getInstance(database, apiService, pref)
    }
}