package com.dicoding.storyapp_sub1.data.response

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.liveData
import androidx.paging.ExperimentalPagingApi
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import androidx.paging.liveData
import com.dicoding.storyapp_sub1.data.preference.User
import com.dicoding.storyapp_sub1.data.preference.UserPreference
import com.dicoding.storyapp_sub1.database.DatabaseStory
import com.dicoding.storyapp_sub1.paging.StoryRemoteMediator
import com.dicoding.storyapp_sub1.retrofit.ApiService
import com.google.gson.Gson
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Response

class UserRepository private constructor(
    private val apiService: ApiService,
    private val userPreference: UserPreference,
    private val database: DatabaseStory
) {

    private var _loginResult = MutableLiveData<LoginResponse>()
    var loginResult: MutableLiveData<LoginResponse> = _loginResult

    var _isLoading = MutableLiveData<Boolean>()
    var isLoading: LiveData<Boolean> = _isLoading

    fun getStory(): LiveData<PagingData<ListStoryItem>> {
        @OptIn(ExperimentalPagingApi::class)
        return Pager(config = PagingConfig(
            pageSize = 5
        ),
            remoteMediator = StoryRemoteMediator(database, apiService),
            pagingSourceFactory = {
                database.storyDao().getAllStory()
            }
        ).liveData
    }


    suspend fun getStoriesWithLocation(location: Int = 1): StoryResponse {
        return apiService.getStoriesWithLocation(location)
    }


    suspend fun getStoriesWithLocation(): LiveData<Result<StoryResponse>> = liveData {
        emit(Result.Loading)
            try {
                val response = apiService.getStories(
                    page = 1,
                    size = 100,
                    location = 1
                )

                if (response.error == false) {
                    emit(Result.Success(response))
                } else {
                    emit(Result.Error(response.message.toString()))
                }
            } catch (e: Exception) {
                emit(Result.Error(e.message.toString()))
            }
        }




        suspend fun register(name: String, email: String, password: String): RegisterResponse {
        return apiService.register(name, email, password)
    }

    fun login(email: String, password: String) {
        _isLoading.value = true // Tampilkan loading spinner

        val client = apiService.login(email, password)
        client.enqueue(object : retrofit2.Callback<LoginResponse> {
            override fun onResponse(
                call: Call<LoginResponse>,
                response: Response<LoginResponse>
            ) {
                _isLoading.value = false // Sembunyikan loading spinner

                if (response.isSuccessful) {
                    _loginResult.value = response.body()
                } else {
                    // Tampilkan pesan kesalahan jika respon tidak berhasil (status kode bukan 200 OK)
                    val errorResponse = response.errorBody()?.string()
                    if (errorResponse != null) {
                        val gson = Gson()
                        val errorData = gson.fromJson(errorResponse, LoginResponse::class.java)
                        _loginResult.value = errorData
                    }
                }
            }

            override fun onFailure(call: Call<LoginResponse>, t: Throwable) {
                _isLoading.value = false // Sembunyikan loading spinner
                Log.e("Repository", "error: ${t.message}")
            }
        })
    }

    suspend fun saveSession(user: User) {
        userPreference.saveUserSession(user)
    }

    fun getSession(): Flow<User> {
        return userPreference.getUserSession()
    }

    suspend fun logout() {
        userPreference.deleteUserSession()
    }

    suspend fun uploadImage(
        file: MultipartBody.Part,
        description: RequestBody,
        lat: Float,
        lon: Float
    ): LiveData<Result<AddstoryResponse>> = liveData {
        emit(Result.Loading)
        val response = if (lat != 0f && lon != 0f) {
            apiService.uploadImageWithLocation(file, description, lat, lon)
        } else {
            apiService.addStories(file, description)
        }
        if (response.error == false) {
            emit(Result.Success(response))
        } else {
            emit(Result.Error(response.message.toString()))
        }
    }


    companion object {
        @Volatile
        private var instance: UserRepository? = null

        fun clearInstance() {
            instance = null
        }

        fun getInstance(
            database: DatabaseStory,
            apiService: ApiService,
            userPreference: UserPreference
        ): UserRepository =
            instance ?: synchronized(this) {
                instance ?: UserRepository(apiService, userPreference, database,)
            }.also { instance = it }
    }
}






