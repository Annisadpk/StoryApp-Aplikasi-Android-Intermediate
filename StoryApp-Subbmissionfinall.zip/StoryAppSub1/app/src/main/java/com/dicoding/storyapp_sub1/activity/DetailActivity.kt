package com.dicoding.storyapp_sub1.activity

import android.graphics.text.LineBreaker
import android.os.Build
import android.os.Bundle
import androidx.activity.viewModels
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.dicoding.storyapp_sub1.data.response.ListStoryItem
import com.dicoding.storyapp_sub1.databinding.ActivityDetailBinding
import com.dicoding.storyapp_sub1.R
import com.dicoding.storyapp_sub1.viewmodel.DetailViewModel

@Suppress("DEPRECATION")
class DetailActivity : AppCompatActivity() {
    private lateinit var story: ListStoryItem
    private lateinit var binding: ActivityDetailBinding
    private val viu: DetailViewModel by viewModels()
    @RequiresApi(Build.VERSION_CODES.Q)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            run {
                binding.tvDescription.justificationMode = LineBreaker.JUSTIFICATION_MODE_INTER_WORD
            }
        }

        story = intent.getParcelableExtra(EXTRA_STORY)!!
        viu.setDetailStory(story)
        displayResult()
        setupToolbar()
    }

    private fun setupToolbar(){
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.setDisplayShowTitleEnabled(false)
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun displayResult() {
        with(binding){
            tvName.text = story.name
            tvDescription.text = story.description
            tvCreatedTime.text = story.createdAt

            Glide.with(ivStory)
                .load(viu.storyItem.photoUrl)
                .placeholder(R.drawable.ph_image)
                .error(R.drawable.ph_image)
                .into(ivStory)
        }
    }

    companion object {
        const val EXTRA_STORY = "story"
    }
}
