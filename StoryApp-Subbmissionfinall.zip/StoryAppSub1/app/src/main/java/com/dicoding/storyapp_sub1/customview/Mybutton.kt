package com.dicoding.storyapp_sub1.customview
import android.content.Context
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.Gravity
import androidx.appcompat.widget.AppCompatButton
import androidx.core.content.ContextCompat
import com.dicoding.storyapp_sub1.R

class Mybutton : AppCompatButton {

    private lateinit var enabledBackground: Drawable
    private lateinit var disabledBackground: Drawable
    private var txtColor: Int = 1

    private var isLoading: Boolean = false
    private var errorMessage: String? = null

    constructor(context: Context) : super(context) {
        init()
    }

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
        init()
    }

    constructor(context: Context, attrs: AttributeSet, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    ) {
        init()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        if (isLoading) {
            background = disabledBackground
            text = context.getString(R.string.loading)
        } else {
            background = if (isEnabled) enabledBackground else disabledBackground
            if (!errorMessage.isNullOrEmpty()) {
                text = errorMessage
            } else {
                text = context.getString(R.string.logintext)
            }
        }

        textSize = 15f
        gravity = Gravity.CENTER
        setTextColor(txtColor)
    }

    fun setLoading(isLoading: Boolean) {
        this.isLoading = isLoading
        invalidate() // Redraw the button to reflect the changes
    }

    fun setError(errorMessage: String) {
        this.errorMessage = errorMessage
        invalidate() // Redraw the button to reflect the changes
    }

    private fun init() {
        txtColor = ContextCompat.getColor(context, R.color.white)
        enabledBackground = ContextCompat.getDrawable(context, R.drawable.bg_button) as Drawable
        disabledBackground = ContextCompat.getDrawable(context, R.drawable.bg_button_disable) as Drawable
    }
}
