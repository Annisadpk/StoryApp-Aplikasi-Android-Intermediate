package com.dicoding.storyapp_sub1.activity

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.content.res.Resources
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.dicoding.storyapp_sub1.R
import com.dicoding.storyapp_sub1.data.response.ListStoryItem
import com.dicoding.storyapp_sub1.data.response.Result
import com.dicoding.storyapp_sub1.databinding.ActivityMapsBinding
import com.dicoding.storyapp_sub1.viewmodel.MapsViewModel
import com.dicoding.storyapp_sub1.viewmodel.ViewModelFactory
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.LatLngBounds
import com.google.android.gms.maps.model.MapStyleOptions
import com.google.android.gms.maps.model.MarkerOptions
import kotlinx.coroutines.launch


class  MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var viewModelFactory: ViewModelFactory
    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityMapsBinding
    private val viewModel by viewModels<MapsViewModel> {
        ViewModelFactory.getInstance(this)
    }
    private val boundBuilder = LatLngBounds.Builder()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setMapFragment()
        setViewModel()
        setActionBar()

        requestLocationPermission()
    }

    private fun setMapFragment() {
        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    private fun setActionBar() {
        supportActionBar?.title = getString(R.string.title_activity_maps)
    }

    private fun setViewModel() {
        viewModelFactory = ViewModelFactory.getInstance(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        setMapStyle()

        mMap.uiSettings.apply {
            isZoomControlsEnabled = true
            isIndoorLevelPickerEnabled = true
            isCompassEnabled = true
            isMapToolbarEnabled = true
        }


        getStoryLocation()
    }

    private fun setMapStyle() {
        try {
            val success = mMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(this, R.raw.map_style))
            if (!success) {
                Log.e(TAG, "Style parsing failed.")
            }
        } catch (exception: Resources.NotFoundException) {
            Log.e(TAG, "Can't find style. Error: ", exception)
        }
    }

    private fun getStoryLocation() {
        lifecycleScope.launch {
            viewModel.getStoriesWithLocation().observe(this@MapsActivity) { result ->
                when (result) {
                    is Result.Loading -> {
                        Log.d(ContentValues.TAG, "onMapReady: Loading")
                    }

                    is Result.Success -> {
                        showMarker(result.data?.listStory ?: emptyList())
                    }

                    is Result.Error -> {
                        showToast(result.error)
                    }
                }
            }
        }
    }

    private fun showMarker(stories: List<ListStoryItem>) {
        val validMarkers = stories.mapNotNull { story ->
            val lat = story.lat
            val lon = story.lon

            // Gunakan safe call operator untuk menangani nilai nullable
            val latLng = lat?.let { latValue ->
                lon?.let { lonValue ->
                    LatLng(latValue, lonValue)
                }
            }

            latLng?.let {
                boundBuilder.include(it)
                return@mapNotNull it
            }

            return@mapNotNull null
        }

        if (validMarkers.isNotEmpty()) {
            validMarkers.forEach { latLng ->
                mMap.addMarker(
                    MarkerOptions()
                        .position(latLng)
                        .title("Story dari : ${stories.first { it.lat == latLng.latitude && it.lon == latLng.longitude }.name}")
                        .snippet("Deskripsi: ${stories.first { it.lat == latLng.latitude && it.lon == latLng.longitude }.description}")
                )
            }

            val bounds: LatLngBounds = boundBuilder.build()
            mMap.animateCamera(
                CameraUpdateFactory.newLatLngBounds(
                    bounds,
                    resources.displayMetrics.widthPixels,
                    resources.displayMetrics.heightPixels,
                    300
                )
            )
        }
    }



    private fun requestLocationPermission() {
        when {
            isLocationPermissionGranted() -> {
                getStoryLocation()
            }
            else -> {
                requestPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
            }
        }
    }

    private fun isLocationPermissionGranted(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    }


    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) {
                getStoryLocation()
            } else {
                Toast.makeText(
                    this,
                    "Location permission is required to show stories on the map.",
                    Toast.LENGTH_SHORT
                ).show()
                finish()
            }
        }

    private fun showLoad(isLoad: Boolean) {
        if (isLoad){
            binding.progressBar.visibility = View.VISIBLE
        }
        else {
            binding.progressBar.visibility = View.GONE
        }
    }

    private fun showToast(message: String?) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }


    companion object {
        private const val TAG = "MapsActivity"
        }
}